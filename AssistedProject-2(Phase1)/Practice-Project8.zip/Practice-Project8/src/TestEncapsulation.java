
public class TestEncapsulation {

	    public static void main (String[] args)  
	    { 
	        Encapsulation obj = new Encapsulation(); 
	        obj.setName("Sriviji"); 
	        obj.setAge(22); 
	        obj.setRoll(41); 
	        System.out.println("My name: " + obj.getName()); 
	        System.out.println("My age: " + obj.getAge()); 
	        System.out.println("My roll: " + obj.getRoll());      
	    } 
	}
