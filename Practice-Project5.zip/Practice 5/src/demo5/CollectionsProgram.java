package demo5;
	import java.util.ArrayList;
	import java.util.LinkedList;

	public class CollectionsProgram {
		public static void main(String[] args) {
			
		//Array list collection
	 ArrayList a1=new ArrayList();
	 a1.add(10);
	 a1.add('a');
	 a1.add(true);
	 a1.add("hello");
	 a1.add(10);
	 a1.add(10.12);
	 System.out.println(a1);
	 System.out.println(a1.size());
	 System.out.println(a1.get(4));
	 System.out.println(a1.indexOf(true));
	 System.out.println(a1.lastIndexOf(10));
	 System.out.println(a1.set(3, "bye"));
	 System.out.println(a1.remove(1));
	 a1.clear();
	 System.out.println(a1.isEmpty());
	 
	}
	}
