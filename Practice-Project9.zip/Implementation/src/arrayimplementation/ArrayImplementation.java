package arrayimplementation;

public class ArrayImplementation{
	

		public static void main(String[] args) {

		//single-dimensional array
		int a[]= {5,10,15,20,50};
		for(int i=0;i<5;i++) {
		System.out.println("Elements of array a: "+a[i]);
		}


		//multidimensional array
		int[][] b= {
		            {2, 5, 9, },
		            {1, 4, 7  },
		            {3, 6, 9} 
		            };
		      
		      System.out.println("\nLength of row 1: " +b[0].length);
		      }
		}

