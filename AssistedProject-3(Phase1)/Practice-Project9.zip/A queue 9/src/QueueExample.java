
import java.util.LinkedList;
import java.util.Queue;

public class QueueExample {
    public static void main(String[] args) {
        // Create a queue using LinkedList
        Queue<Integer> queue = new LinkedList<>();

        // Enqueue (insert) elements into the queue
        queue.offer(10);
        queue.offer(20);
        queue.offer(30);
        queue.offer(40);
        queue.offer(50);
        queue.offer(60);

        System.out.println("Queue elements: " + queue);

        // Dequeue (remove) elements from the queue
        int removedElement = queue.poll();
        System.out.println("Removed element: " + removedElement);
        System.out.println("Updated queue: " + queue);
        System.out.println("Size of Queue : " + queue.size());
    }
}

