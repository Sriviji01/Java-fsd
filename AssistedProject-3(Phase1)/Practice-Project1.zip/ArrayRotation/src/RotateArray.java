import java.util.Arrays;

public class RotateArray {
    public static void Rotate(int[] arr, int steps) {
        int n = arr.length;
        steps = steps % n; // Ensure steps is within the array size

        // Reverse the entire array
        reverseArray(arr, 0, n - 1);
        
        // Reverse the first 'steps' elements
        reverseArray(arr, 0, steps - 1);
        
        // Reverse the remaining elements
        reverseArray(arr, steps, n - 1);
    }

    public static void reverseArray(int[] arr, int start, int end) {
        while (start < end) {
            int temp = arr[start];
            arr[start] = arr[end];
            arr[end] = temp;
            start++;
            end--;
        }
    }

    public static void main(String[] args) {
        int[] arr = {1, 2, 3, 4, 5, 6, 7, 8, 9};
        int steps = 5;
        
        System.out.println("Original Array: " + Arrays.toString(arr));
        Rotate(arr, steps);
        System.out.println(" Rotated Array by " + steps + " steps: " + Arrays.toString(arr));
    }
}
