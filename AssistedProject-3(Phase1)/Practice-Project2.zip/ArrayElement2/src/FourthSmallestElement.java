import java.util.Arrays;
public class FourthSmallestElement {
    public static int findFourthSmallest(int[] arr) {
        if (arr == null || arr.length < 4) {
            throw new IllegalArgumentException("Input array must have at least 4 elements");
        }

        Arrays.sort(arr); 

        return arr[3];
    }

    public static void main(String[] args) {
        int[] arr = {4, 3, 16, 28, 15, 6, 21, 24};
        int fourthSmallest = findFourthSmallest(arr);
        		System.out.println("Fourth Smallest Element: " + fourthSmallest);
    }
}

