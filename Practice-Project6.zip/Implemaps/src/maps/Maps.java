package maps;
import java.util.*;

public class Maps {

	
	
		public static void main(String[] args) {
			
			HashMap<Integer,String> hashmap=new HashMap<Integer,String>();      
		      hashmap.put(1,"Pooja");    
		      hashmap.put(2,"Viji");    
		      hashmap.put(3,"Meena");   
		       
		      System.out.println("\nThe elements of Hashmap are ");  
		      for(Map.Entry map:hashmap.entrySet()){    
		       System.out.println(map.getKey()+" "+map.getValue());    
		      }
		      
		     //HashTable
		       
		      Hashtable<Integer,String> hashtable=new Hashtable<Integer,String>();  
		      
		      hashtable.put(4,"Aishu");  
		      hashtable.put(5,"Reshu");  
		      hashtable.put(6,"Janu");  
		      hashtable.put(7,"Jothi");  

		      System.out.println("\nThe elements of HashTable are ");  
		      for(Map.Entry n:hashtable.entrySet()){    
		       System.out.println(n.getKey()+" "+n.getValue());    
		      }
		      
		      
		      //TreeMap
		      
		      TreeMap<Integer,String> map=new TreeMap<Integer,String>();    
		      map.put(8,"Anitha");    
		      map.put(9,"Cathrine");    
		      map.put(10,"swetha");       
		      
		      System.out.println("\nThe elements of TreeMap are ");  
		      for(Map.Entry l:map.entrySet()){    
		       System.out.println(l.getKey()+" "+l.getValue());    
		      }    
		      
		   
	
}
}