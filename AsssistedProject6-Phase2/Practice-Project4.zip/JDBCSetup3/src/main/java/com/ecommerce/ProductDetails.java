package com.ecommerce;

import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection; // Import Connection class
import java.sql.DriverManager; // Import DriverManager class
import java.sql.SQLException;
import java.util.Properties;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/ProductDetails")
public class ProductDetails extends HttpServlet {
    private static final long serialVersionUID = 1L;

    public ProductDetails() {
        super();
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            PrintWriter out = response.getWriter();
            out.println("<html><body>");

            // Load the database connection properties from a config file
            InputStream in = getServletContext().getResourceAsStream("/WEB-INF/config.properties");
            Properties props = new Properties();
            props.load(in);

            // Establish a database connection
            Class.forName("com.mysql.jdbc.Driver"); // Load the MySQL JDBC driver
            Connection conn = DriverManager.getConnection(props.getProperty("url"), props.getProperty("userid"),
                    props.getProperty("password"));

            // Prepare and execute the stored procedure
            CallableStatement stmt = conn.prepareCall("{call add_product(?, ?)}");
            stmt.setString(1, "new product");
            stmt.setBigDecimal(2, new BigDecimal(1900.50));
            stmt.executeUpdate();

            out.println("Stored procedure has been executed.<br>");
            stmt.close();

            out.println("</body></html>");

            // Close the database connection
            conn.close();

        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        doGet(request, response);
    }
}
