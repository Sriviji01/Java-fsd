package modifierimport;
import demo.*;
public class acessimport extends Project_Assisted2{
	public static void main(String[]args) {
		acessimport obj=new acessimport();
		obj.display();
		System.out.println("");
		obj.display();
	}

}