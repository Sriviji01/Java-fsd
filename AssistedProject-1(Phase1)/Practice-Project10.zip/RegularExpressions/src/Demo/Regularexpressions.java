package Demo;
import java.util.regex.*;
	public class Regularexpressions {
	public static void main(String[] args) {

		String pattern = "[a-z]+";
		String check = "String my program";
		Pattern p = Pattern.compile(pattern);
		Matcher m = p.matcher(check);
		
		while (m.find())
	      	System.out.println( check.substring( m.start(), m.end() ) );
		}
	}

