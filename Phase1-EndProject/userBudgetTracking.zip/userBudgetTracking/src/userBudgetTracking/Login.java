package userBudgetTracking;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Login {
    private List<User> users;

    public Login() {
        users = new ArrayList<>();
 
        users.add(new User("john", "john123"));
        users.add(new User("srivi", "srivi01"));
        users.add(new User("antony", "antony123"));
        users.add(new User("miller", "miller01"));
        users.add(new User("testuser", "testuser123"));
        users.add(new User("anil", "anil07"));
    
    }

    public User authenticate(Scanner scanner) {
        System.out.println("+--------------------------------+");
        System.out.println("| WELCOME TO BUDGET TRACKER APP  |");
        System.out.println("+--------------------------------+");
        System.out.println("\nPlease login to continue");
        System.out.println("\nEnter the username: ");
        String enteredUsername = scanner.next();
        System.out.println("Enter the password: ");
        String enteredPassword = scanner.next();
        System.out.println("Successfully logged in");

        for (User user : users) {
        	
            if (user.getUsername().equals(enteredUsername) && user.getPassword().equals(enteredPassword)) {
                return user;
            }
        }

        return null; 
    }
}
