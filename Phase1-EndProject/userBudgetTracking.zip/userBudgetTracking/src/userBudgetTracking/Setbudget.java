package userBudgetTracking;

import java.util.Scanner;

public class Setbudget {
    public static double setMonthlyBudget(Scanner scanner, User user) {
        System.out.println("Enter the monthly budget amount for user " + user.getUsername() + ": ");
        double newBudget = scanner.nextDouble();
        scanner.nextLine(); // Consume newline

        user.setMonthlyBudget(newBudget);
        System.out.println("Monthly budget set to $" + newBudget + " for user " + user.getUsername());
        return newBudget;
    }

    public static double updateMonthlyBudget(Scanner scanner, User user) {
        System.out.print("Do you want to update the monthly budget for user " + user.getUsername() + "? (Y/N): ");
        String confirmation = scanner.nextLine().trim();

        double newBudget = user.getMonthlyBudget(); // Initialize with the current budget

        if (confirmation.equalsIgnoreCase("Y")) {
            System.out.print("Enter the updated monthly budget amount for user " + user.getUsername() + ": ");
            double updatedBudget = scanner.nextDouble();
            scanner.nextLine(); // Consume newline

            user.setMonthlyBudget(updatedBudget);
            newBudget = updatedBudget; // Save the updated budget into newBudget
            System.out.println("\nMonthly budget updated to $" + updatedBudget + " for user " + user.getUsername());
        } else {
            System.out.println("\nMonthly budget not updated for user " + user.getUsername());
        }

        return newBudget;
    }

    public static double getMonthlyBudget(User user) {
        return user.getMonthlyBudget();
    }
}
