package userBudgetTracking;
import java.util.Scanner;

public class Passwordchange {
    public static void changePassword(String username, String currentPassword, Scanner scanner) {
        System.out.print("Enter your old password: ");
        String enteredCurrentPassword = scanner.nextLine();

        if (currentPassword.equals(enteredCurrentPassword)) {
            System.out.print("Enter your new password: ");
            @SuppressWarnings("unused")
			String newPassword = scanner.nextLine();
            System.out.println("Password changed successfully for user " + username);
        } else {
            System.out.println("Current password is incorrect.");
        }
    }
}
